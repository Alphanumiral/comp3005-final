--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "3005-Final-DB";
--
-- Name: 3005-Final-DB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "3005-Final-DB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Canada.1252';


ALTER DATABASE "3005-Final-DB" OWNER TO postgres;

\connect -reuse-previous=on "dbname='3005-Final-DB'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: add_cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.add_cart (
    cartid numeric(8,2) NOT NULL,
    bookid character varying(30) NOT NULL
);


ALTER TABLE public.add_cart OWNER TO postgres;

--
-- Name: author; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.author (
    name character varying(20) NOT NULL
);


ALTER TABLE public.author OWNER TO postgres;

--
-- Name: book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book (
    id character varying(30) NOT NULL,
    title character varying(30),
    price numeric(8,2),
    genre character varying(15),
    reorder numeric(8,2),
    stock numeric(8,2),
    publishercut numeric(8,2)
);


ALTER TABLE public.book OWNER TO postgres;

--
-- Name: bookspecs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookspecs (
    bookid character varying(30) NOT NULL,
    authorname character varying(30) NOT NULL,
    pubname character varying(30)
);


ALTER TABLE public.bookspecs OWNER TO postgres;

--
-- Name: cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart (
    id numeric(8,2) NOT NULL
);


ALTER TABLE public.cart OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    username character varying(30) NOT NULL,
    password character varying(30),
    cartid numeric(8,2),
    shipid character varying(30),
    payid character varying(30)
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: orderm; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orderm (
    onum numeric(14,2) NOT NULL,
    trucknum numeric(8,2),
    facility character varying(30),
    city character varying(30),
    province character varying(30),
    cuser character varying(30),
    shipid character varying(30),
    payid character varying(30)
);


ALTER TABLE public.orderm OWNER TO postgres;

--
-- Name: owner; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.owner (
    username character varying(30) NOT NULL,
    password character varying(30)
);


ALTER TABLE public.owner OWNER TO postgres;

--
-- Name: payment_info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_info (
    id character varying(30) NOT NULL,
    number numeric(14,2),
    threenum numeric(4,1),
    day numeric(3,1),
    month numeric(3,1),
    year numeric(5,1)
);


ALTER TABLE public.payment_info OWNER TO postgres;

--
-- Name: phone_number; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.phone_number (
    pub_name character varying(30) NOT NULL,
    number numeric(13,2) NOT NULL
);


ALTER TABLE public.phone_number OWNER TO postgres;

--
-- Name: publisher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.publisher (
    name character varying(30) NOT NULL,
    email character varying(30),
    address character varying(30),
    banking_acc numeric(8,2)
);


ALTER TABLE public.publisher OWNER TO postgres;

--
-- Name: shipping_info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_info (
    id character varying(30) NOT NULL,
    address character varying(30),
    postcode character varying(30),
    province character varying(15),
    city character varying(20)
);


ALTER TABLE public.shipping_info OWNER TO postgres;

--
-- Name: sold_books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sold_books (
    onum numeric(14,2) NOT NULL,
    bookid character varying(30) NOT NULL
);


ALTER TABLE public.sold_books OWNER TO postgres;

--
-- Data for Name: add_cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.add_cart (cartid, bookid) FROM stdin;
\.
COPY public.add_cart (cartid, bookid) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: author; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.author (name) FROM stdin;
\.
COPY public.author (name) FROM '$$PATH$$/3390.dat';

--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book (id, title, price, genre, reorder, stock, publishercut) FROM stdin;
\.
COPY public.book (id, title, price, genre, reorder, stock, publishercut) FROM '$$PATH$$/3391.dat';

--
-- Data for Name: bookspecs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookspecs (bookid, authorname, pubname) FROM stdin;
\.
COPY public.bookspecs (bookid, authorname, pubname) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart (id) FROM stdin;
\.
COPY public.cart (id) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (username, password, cartid, shipid, payid) FROM stdin;
\.
COPY public.customer (username, password, cartid, shipid, payid) FROM '$$PATH$$/3397.dat';

--
-- Data for Name: orderm; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orderm (onum, trucknum, facility, city, province, cuser, shipid, payid) FROM stdin;
\.
COPY public.orderm (onum, trucknum, facility, city, province, cuser, shipid, payid) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: owner; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.owner (username, password) FROM stdin;
\.
COPY public.owner (username, password) FROM '$$PATH$$/3402.dat';

--
-- Data for Name: payment_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_info (id, number, threenum, day, month, year) FROM stdin;
\.
COPY public.payment_info (id, number, threenum, day, month, year) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: phone_number; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.phone_number (pub_name, number) FROM stdin;
\.
COPY public.phone_number (pub_name, number) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: publisher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.publisher (name, email, address, banking_acc) FROM stdin;
\.
COPY public.publisher (name, email, address, banking_acc) FROM '$$PATH$$/3395.dat';

--
-- Data for Name: shipping_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_info (id, address, postcode, province, city) FROM stdin;
\.
COPY public.shipping_info (id, address, postcode, province, city) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: sold_books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sold_books (onum, bookid) FROM stdin;
\.
COPY public.sold_books (onum, bookid) FROM '$$PATH$$/3399.dat';

--
-- Name: add_cart add_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.add_cart
    ADD CONSTRAINT add_cart_pkey PRIMARY KEY (cartid, bookid);


--
-- Name: author author_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.author
    ADD CONSTRAINT author_pkey PRIMARY KEY (name);


--
-- Name: book book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pkey PRIMARY KEY (id);


--
-- Name: bookspecs bookspecs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookspecs
    ADD CONSTRAINT bookspecs_pkey PRIMARY KEY (bookid, authorname);


--
-- Name: cart cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (username);


--
-- Name: orderm orderm_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orderm
    ADD CONSTRAINT orderm_pkey PRIMARY KEY (onum);


--
-- Name: owner owner_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.owner
    ADD CONSTRAINT owner_pkey PRIMARY KEY (username);


--
-- Name: payment_info payment_info_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_info
    ADD CONSTRAINT payment_info_pkey PRIMARY KEY (id);


--
-- Name: phone_number phone_number_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.phone_number
    ADD CONSTRAINT phone_number_pkey PRIMARY KEY (pub_name, number);


--
-- Name: publisher publisher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publisher
    ADD CONSTRAINT publisher_pkey PRIMARY KEY (name);


--
-- Name: shipping_info shipping_info_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_info
    ADD CONSTRAINT shipping_info_pkey PRIMARY KEY (id);


--
-- Name: sold_books sold_books_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sold_books
    ADD CONSTRAINT sold_books_pkey PRIMARY KEY (onum, bookid);


--
-- Name: add_cart add_cart_bookid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.add_cart
    ADD CONSTRAINT add_cart_bookid_fkey FOREIGN KEY (bookid) REFERENCES public.book(id);


--
-- Name: add_cart add_cart_cartid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.add_cart
    ADD CONSTRAINT add_cart_cartid_fkey FOREIGN KEY (cartid) REFERENCES public.cart(id);


--
-- Name: bookspecs bookspecs_authorname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookspecs
    ADD CONSTRAINT bookspecs_authorname_fkey FOREIGN KEY (authorname) REFERENCES public.author(name);


--
-- Name: bookspecs bookspecs_bookid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookspecs
    ADD CONSTRAINT bookspecs_bookid_fkey FOREIGN KEY (bookid) REFERENCES public.book(id);


--
-- Name: bookspecs bookspecs_pubname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookspecs
    ADD CONSTRAINT bookspecs_pubname_fkey FOREIGN KEY (pubname) REFERENCES public.publisher(name);


--
-- Name: customer customer_cartid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_cartid_fkey FOREIGN KEY (cartid) REFERENCES public.cart(id);


--
-- Name: customer customer_payid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_payid_fkey FOREIGN KEY (payid) REFERENCES public.payment_info(id);


--
-- Name: customer customer_shipid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_shipid_fkey FOREIGN KEY (shipid) REFERENCES public.shipping_info(id);


--
-- Name: orderm orderm_cuser_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orderm
    ADD CONSTRAINT orderm_cuser_fkey FOREIGN KEY (cuser) REFERENCES public.customer(username);


--
-- Name: orderm orderm_payid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orderm
    ADD CONSTRAINT orderm_payid_fkey FOREIGN KEY (payid) REFERENCES public.payment_info(id);


--
-- Name: orderm orderm_shipid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orderm
    ADD CONSTRAINT orderm_shipid_fkey FOREIGN KEY (shipid) REFERENCES public.shipping_info(id);


--
-- Name: phone_number phone_number_pub_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.phone_number
    ADD CONSTRAINT phone_number_pub_name_fkey FOREIGN KEY (pub_name) REFERENCES public.publisher(name);


--
-- Name: sold_books sold_books_bookid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sold_books
    ADD CONSTRAINT sold_books_bookid_fkey FOREIGN KEY (bookid) REFERENCES public.book(id);


--
-- Name: sold_books sold_books_onum_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sold_books
    ADD CONSTRAINT sold_books_onum_fkey FOREIGN KEY (onum) REFERENCES public.orderm(onum);


--
-- PostgreSQL database dump complete
--

